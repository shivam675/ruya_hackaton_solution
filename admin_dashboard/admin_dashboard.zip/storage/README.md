# Storage Directories

This folder stores uploaded files and generated content:

- `cvs/` - Uploaded candidate CVs
- `recordings/` - Interview audio recordings
- `transcripts/` - Interview transcripts (JSON format)

Created automatically by the application if missing.

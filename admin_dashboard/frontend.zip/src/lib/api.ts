import axios from 'axios';

const API_BASE_URL = (import.meta as any).env?.VITE_API_URL || 'http://localhost:8001';

export const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Authentication has been removed - all endpoints are now public

// Auth API - DISABLED (kept for compatibility)
export const authAPI = {
  login: async (_email: string, _password: string) => {
    throw new Error('Authentication is disabled');
  },
  getCurrentUser: async () => {
    throw new Error('Authentication is disabled');
  },
  logout: async () => {
    throw new Error('Authentication is disabled');
  },
};

// Job Postings API
export const jobPostingsAPI = {
  getAll: async (isActive?: boolean) => {
    const response = await api.get('/job-postings', {
      params: { is_active: isActive },
    });
    return response.data;
  },
  getById: async (id: string) => {
    const response = await api.get(`/job-postings/${id}`);
    return response.data;
  },
  create: async (data: any) => {
    const response = await api.post('/job-postings', data);
    return response.data;
  },
  update: async (id: string, data: any) => {
    const response = await api.put(`/job-postings/${id}`, data);
    return response.data;
  },
  delete: async (id: string) => {
    const response = await api.delete(`/job-postings/${id}`);
    return response.data;
  },
};

// Candidates API
export const candidatesAPI = {
  fetchFromCVAgent: async (jobId: string) => {
    const response = await api.post(`/candidates/fetch-from-cv-agent/${jobId}`);
    return response.data;
  },
  getByJob: async (jobId: string, status?: string) => {
    const response = await api.get(`/candidates/job/${jobId}`, {
      params: { status_filter: status },
    });
    return response.data;
  },
  getById: async (id: string) => {
    const response = await api.get(`/candidates/${id}`);
    return response.data;
  },
  update: async (id: string, data: any) => {
    const response = await api.put(`/candidates/${id}`, data);
    return response.data;
  },
  approve: async (candidateIds: string[], sendEmail: boolean = true) => {
    const response = await api.post('/candidates/approve', {
      candidate_ids: candidateIds,
      send_email: sendEmail,
    });
    return response.data;
  },
  delete: async (id: string) => {
    const response = await api.delete(`/candidates/${id}`);
    return response.data;
  },
};

// Interviews API
export const interviewsAPI = {
  create: async (data: any) => {
    const response = await api.post('/interviews', data);
    return response.data;
  },
  getAll: async (jobPostingId?: string, status?: string) => {
    const response = await api.get('/interviews', {
      params: { job_posting_id: jobPostingId, status_filter: status },
    });
    return response.data;
  },
  getById: async (id: string) => {
    const response = await api.get(`/interviews/${id}`);
    return response.data;
  },
  getByCandidate: async (candidateId: string) => {
    const response = await api.get(`/interviews/candidate/${candidateId}`);
    return response.data;
  },
  update: async (id: string, data: any) => {
    const response = await api.put(`/interviews/${id}`, data);
    return response.data;
  },
  authenticateCandidate: async (name: string) => {
    const response = await api.post('/interviews/candidate-auth', { name });
    return response.data;
  },
};

// Learning API
export const learningAPI = {
  getAllMetrics: async () => {
    const response = await api.get('/learning/metrics');
    return response.data;
  },
  getMetrics: async (agentType: string) => {
    const response = await api.get(`/learning/metrics/${agentType}`);
    return response.data;
  },
  getInsights: async (agentType: string) => {
    const response = await api.get(`/learning/insights/${agentType}`);
    return response.data;
  },
  getLearningState: async (agentType: string) => {
    const response = await api.get(`/learning/state/${agentType}`);
    return response.data;
  },
  updateLearningState: async (agentType: string, updates: any) => {
    const response = await api.put(`/learning/state/${agentType}`, updates);
    return response.data;
  },
  submitFeedback: async (data: any) => {
    const response = await api.post('/learning/feedback', data);
    return response.data;
  },
  getEvolution: async (agentType: string) => {
    const response = await api.get(`/learning/evolution/${agentType}`);
    return response.data;
  },
};

// HR Chat API
export const hrChatAPI = {
  sendMessage: async (message: string) => {
    const response = await api.post('/hr-chat/message', { message });
    return response.data;
  },
  submitFeedback: async (messageId: string, rating: number, comments?: string) => {
    const response = await api.post('/hr-chat/feedback', {
      message_id: messageId,
      rating,
      comments,
    });
    return response.data;
  },
  checkHealth: async () => {
    const response = await api.get('/hr-chat/health');
    return response.data;
  },
};

// Critic Agent API
export const criticAPI = {
  evaluateAgent: async (agentType: string, limitSamples?: number) => {
    const response = await api.post('/critic/evaluate', {
      agent_type: agentType,
      limit_samples: limitSamples || 10,
    });
    return response.data;
  },
  listImprovements: async (agentType?: string, status?: string) => {
    const response = await api.get('/critic/improvements', {
      params: { agent_type: agentType, status },
    });
    return response.data;
  },
  getImprovement: async (evaluationId: string) => {
    const response = await api.get(`/critic/improvements/${evaluationId}`);
    return response.data;
  },
  approveImprovement: async (evaluationId: string) => {
    const response = await api.post(`/critic/improvements/${evaluationId}/approve`);
    return response.data;
  },
  rejectImprovement: async (evaluationId: string, reason?: string) => {
    const response = await api.post(`/critic/improvements/${evaluationId}/reject`, {
      evaluation_id: evaluationId,
      reason,
    });
    return response.data;
  },
  getCurrentPrompt: async (agentType: string) => {
    const response = await api.get(`/critic/prompt/${agentType}`);
    return response.data;
  },
  checkHealth: async () => {
    const response = await api.get('/critic/health');
    return response.data;
  },
};

export default api;
